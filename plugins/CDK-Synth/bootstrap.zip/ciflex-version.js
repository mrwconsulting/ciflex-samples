#!/usr/bin/env node
const { execSync } = require('node:child_process')

var default_version = 'latest'
var secret_id = 'mrwconsulting/ciflex/config'
var ciflex_version = execSync(`aws secretsmanager get-secret-value --secret-id ${secret_id} --query SecretString --output text | jq -r .config | jq -r .version.ciflex`).toString('utf-8');

if (ciflex_version.trim().length = 0) ciflex_version = default_version
console.log('CIFLEX_VERSION: ', ciflex_version)

var custom_version_enabled = process.env.CUSTOM_VERSION_ENABLED || 'false'
if (custom_version_enabled.toLowerCase() == 'true') {
    var custom_pipeline_version = process.env.CUSTOM_PIPELINE_VERSION || ''
    if (custom_pipeline_version.length > 0) {
        console.log('CUSTOM_VERSION_ENABLED:', custom_version_enabled)
        console.log('CUSTOM_PIPELINE_VERSION: ', custom_pipeline_version)
        ciflex_version = custom_pipeline_version
        console.log('RESETTED CIFLEX_VERSION: ', ciflex_version)
    }
}

execSync(`npm install @mrwconsulting/ciflex@${ciflex_version}`, {
    stdio: 'inherit'
})
